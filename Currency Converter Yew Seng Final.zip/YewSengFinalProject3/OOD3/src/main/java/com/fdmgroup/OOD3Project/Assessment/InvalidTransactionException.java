package com.fdmgroup.OOD3Project.Assessment;
/**
 * Custom Exception class. InvalidTransactionException is thrown when one of the following occurs:
 * <li> user is trying to convert an amount greater than the remains of his wallet in the associated currency
 * <li> user does not have a wallet of the associated currency
 * @author Tan Yew Seng 
 * @version 1.0
 */

public class InvalidTransactionException extends Exception {


	private static final long serialVersionUID = 1L;

	/**
	 * Constructor method for InvalidTransactionException
	 * Prints error message on console when one of the following occurs:
	 * <li> user is trying to convert an amount greater than the remains of his wallet in the associated currency
	 * <li> user does not have a wallet of the associated currency
	 * @param message
	 */
	public InvalidTransactionException(String message) {
		super(message);
	}
}
