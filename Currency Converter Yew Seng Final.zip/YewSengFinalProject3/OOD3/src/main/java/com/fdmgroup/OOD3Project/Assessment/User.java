package com.fdmgroup.OOD3Project.Assessment;


import java.util.HashMap;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * User class to store the attributes of individual user
 * @author Tan Yew Seng
 * @version 1.0
 */



public class User {

	/**
	 * User name
	 */
	private String name;
	/**
	 * user wallet store in Hashmap in the form of <String,Double>
	 */
	private HashMap<String,Double> wallet = new HashMap<>();
	/**
	 * Constructor method for User class
	 * @param name
	 * @param wallet
	 */
	@JsonCreator
	public User(@JsonProperty("name")String name,@JsonProperty("wallet") HashMap<String,Double> wallet) {
		this.name = name;
		this.wallet = wallet;
	}
	/**
	 * Getter method for User name
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * Getter method for User wallet
	 * @return wallet
	 */
	public HashMap<String,Double> getWallet(){
		return this.wallet;
	}
	/**
	 * Update the contents of wallet if new currency is added into the wallet
	 * else keep the value of wallet the same
	 * @param currency
	 * @param amount
	 */
	public void updateNewCurrencyWallet(String currency, double amount) {
		if (wallet.containsKey(currency)) {
			double currentAmount = wallet.get(currency);
			double newAmount = currentAmount + amount;
			wallet.put(currency, newAmount);
		} else {
			wallet.put(currency, amount);
		}
	}
	/**
	 * Update the contents of wallet when currency is used to exchange into other forms of currency
	 * @param currency
	 * @param amount
	 */
	public void updateOldCurrencyWallet(String currency, double amount) {
				double currentAmount = wallet.get(currency);
				double newAmount = currentAmount - amount;
				wallet.put(currency, newAmount);
	}
}
