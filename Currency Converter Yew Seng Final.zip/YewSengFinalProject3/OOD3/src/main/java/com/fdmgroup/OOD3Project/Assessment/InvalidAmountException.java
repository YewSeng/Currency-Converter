package com.fdmgroup.OOD3Project.Assessment;
/**
 * Custom Exception class. InvalidAmountException is thrown when one of the following occurs:
 * <li> amount is not an instanceof Double
 * <li> amount is <= 0
 * @author Tan Yew Seng 
 * @version 1.0
 */

public class InvalidAmountException extends Exception {


	private static final long serialVersionUID = 1L;

	/**
	 * Constructor method for InvalidAmountException
	 * Prints error message on console when one of the following occurs:
	 * <li> amount is not an instanceof Double
	 * <li> amount is <= 0
	 * @param message
	 */
	public InvalidAmountException(String message) {
		super(message);
	}
}
