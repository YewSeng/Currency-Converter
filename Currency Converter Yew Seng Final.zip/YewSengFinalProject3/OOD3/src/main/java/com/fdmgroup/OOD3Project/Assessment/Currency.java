package com.fdmgroup.OOD3Project.Assessment;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import com.fasterxml.jackson.databind.ObjectMapper;
/**
 * Class to obtain a HashMap of key/value pair of the contents of currencies
 * @author Tan Yew Seng
 * @version 1.0
 */

public class Currency {

	/**
	 * Deserialize json format objects to obtain a HashMap of key/value pair of the contents of the currencies
	 * @return HashMap<String,CurrencyData>
	 */
	public static HashMap<String,CurrencyData> getCurrencies() {
		HashMap<String,CurrencyData> currencies = null;
		ObjectMapper mapper = new ObjectMapper();
		try {
			currencies = mapper.readValue(new File(".\\src\\main\\resources\\fx_rates.json"), HashMap.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return currencies;		
	}
}
