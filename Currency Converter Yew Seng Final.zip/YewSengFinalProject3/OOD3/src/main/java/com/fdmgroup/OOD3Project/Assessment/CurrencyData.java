package com.fdmgroup.OOD3Project.Assessment;

import java.sql.Date;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Class to store the values of each individual currency code (eg: "eur")
 * @author Tan Yew Seng
 * @version 1.0
 */
public class CurrencyData {
	/** 
	 * Currency code
	 */
	private	String code;
	/**
	 * Currency alphaCode
	 */
	private String alphaCode;
	/**
	 * Currency numericCode
	 */
	private String numericCode;
	/**
	 * Currency name
	 */
	private String name;
	/**
	 * Currency rate
	 */
	private double rate;
	/**
	 * Currency date
	 */
	private Date date;
	/**
	 * Currency inverseRate
	 */
	private double inverseRate;
	/**
	 * Constructor method for CurrencyData class to extract contents of the value of each individual currency
	 * @param code
	 * @param alphaCode
	 * @param numericCode
	 * @param name
	 * @param rate
	 * @param inverseRate
	 * @param date
	 */
	@JsonCreator
	public CurrencyData(@JsonProperty("code")String code, @JsonProperty("alphaCode")String alphaCode,@JsonProperty("numericCode")String numericCode,@JsonProperty("name")String name,@JsonProperty("rate")double rate,@JsonProperty("inverseRate")double inverseRate,@JsonProperty("date") Date date) {
		this.code = code;
		this.alphaCode = alphaCode;
		this.numericCode = numericCode;
		this.name = name;
		this.rate = rate;
		this.date = date;
		this.inverseRate = inverseRate;
	}
	
	/**
	 * Getter method for Currency code
	 * @return code 
	 */
	public String getCode() {
		return code;
	}
	/**
	 * Getter method for Currency alphaCode
	 * @return alphaCode
	 */
	public String getAlphaCode() {
		return alphaCode;
	}
	/**
	 * Getter method for Currency numericCode
	 * @return numericCode
	 */
	public String getNumericCode() {
		return numericCode;
	}
	/**
	 * Getter method for Currency name
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * Getter method for Currency rate
	 * @return rate
	 */
	public double getRate() {
		return rate;
	}
	/**
	 * Getter method for Currency date
	 * @return date
	 */
	public Date getDate() {
		return date;
	}
	/**
	 * Getter method for Currency inverseRate
	 * @return inverseRate
	 */
	public double getInverseRate() {
		return inverseRate;
	}
}
