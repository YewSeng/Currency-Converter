package com.fdmgroup.OOD3Project.Assessment;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Class to obtain a list of Users from the Users.json file by deserializing via ObjectMapper class using the readValue method
 * <p>Calls the class User and thus able to access User methods</p>
 * <p>Gets User Name via getName() and gets User Wallet contents via getWallet()(with their currency code and amount)</p>
 * 
 * @author Tan Yew Seng 
 * @version 1.0
 * 
 */
public class AllUsers {
	/**
	 * Obtain a List of users from a file that is in Json format
	 * @param file
	 * @return List<User> 
	 */
	
	public List<User> readFromUsersJSONFile(File file){
		ObjectMapper mapper = new ObjectMapper();
		List<User> users = new ArrayList<>();
		try {
			users = Arrays.asList(mapper.readValue(file, User[].class));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}
	



	
}
