package com.fdmgroup.OOD3Project.Assessment;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import com.fasterxml.jackson.core.exc.StreamWriteException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Class to execute all Transactions given in Transactions.txt file. Will throw the 3 custom Exception Class
 * if conditions are not met
 * @author Tan Yew Seng
 * @version 1.0
 */
public class TransactionProcessor {
	/**
	 * executeTransaction() will check for all valid transactions provided in the transactions.txt file
	 * If transactions are valid, it will execute these transactions and update the new amount of user's
	 * wallet in a new Json format file via calling the UpdateUsersFile(User[] users) method.
	 * @throws InvalidTransactionException
	 * @throws InvalidUserException
	 * @throws InvalidAmountException
	 * @throws IOException
	 */
	public void executeTransaction() throws InvalidTransactionException, InvalidUserException, InvalidAmountException {
	    Logger log = (Logger) LogManager.getLogger(TransactionProcessor.class);
	    String line;
	    String userName;
	    String oldCurrencyCode;
	    String newCurrencyCode;
	    double amountToConvert;
	    boolean userNotFound = false;
	    boolean currencyNotFound = false;
	    boolean insufficientBalance = false;
	    //try-with statement
	    try (BufferedReader br = new BufferedReader(new FileReader(new File(".\\src\\main\\resources\\transactions.txt")))) {
	        // Get a array of users
	    	User[] users = TransactionProcessor.getUsers();
	    	//Instantiate Converter object
	        Converter converter = new Converter();
	        while ((line = br.readLine()) != null) {
	        	// Each arg (space-separated) stands for one of the args
	            String[] transactionArgs = line.split(" ");
	           userName = transactionArgs[0];
	           oldCurrencyCode = transactionArgs[1];
	           newCurrencyCode = transactionArgs[2];
	           amountToConvert = Double.parseDouble(transactionArgs[3]);

	            // Set user as null initially
	            User user = null;
	            /*If user (from transactions.txt) exist in Users.json file
	             * set currentUser as user
	             */
	            for (User currentUser : users) {
	                if (currentUser.getName().equals(userName)) {
	                    user = currentUser;
	                    break;
	                }
	            }
	            //If user not found set boolean userNotFound to true
	            if (user == null) {
	            	userNotFound = true;
	            	continue;
	            }           
	            //If user do not have the oldCurrency wallet, set boolean currencyNotFound to true
	            if (!user.getWallet().containsKey(oldCurrencyCode)) {
	            	currencyNotFound = true;
	            	continue;
	            }
	            //If user is trying to convert an amount greater than his wallet remains, set boolean insufficientBalance to true
	            if (user.getWallet().get(oldCurrencyCode) < amountToConvert) {
	            	insufficientBalance = true;
	            	continue;
	            }
	            // update value of new currency via calling the Converter object and convert method in Converter class
	            double newValue = converter.convert(oldCurrencyCode, newCurrencyCode, amountToConvert);
	            // update new currency wallet value
	            user.updateNewCurrencyWallet(newCurrencyCode, newValue);
	            // update old currency wallet value
	            user.updateOldCurrencyWallet(oldCurrencyCode, amountToConvert);
	            log.info(oldCurrencyCode + ": " + amountToConvert +" is converted to " + newCurrencyCode + ": " + newValue +" and added to " +user.getName()+"'s wallet.");
	            log.info(oldCurrencyCode + ": " + amountToConvert + " is deducted from " + user.getName() + "'s wallet.");
	            log.info(newCurrencyCode + ": " + newValue + " is added to " + user.getName() +"'s wallet.");
	        }
	        // update the UsersUpdated.json file with valid transactions
	        updateUsersFile(users);
	    } catch (FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    // Throw InvalidUserException and log the message 
	    if (userNotFound == true) {
            log.fatal("User does not exist. Please enter a valid user for transaction to proceed. Operation Terminated.");
            throw new InvalidUserException("User does not exist.");
	    }
	    // Throw InvalidTransactionException and log the message
	    if (currencyNotFound == true) {
            log.fatal("Currency does not exist. Please enter a valid currency code (Case Sensitive - Lower Case). Operation Terminated.");
            throw new InvalidTransactionException("Currency does not exist.");
	    }
	    // Throw InvalidTransactionException and log the message
	    if (insufficientBalance == true) {
            log.fatal("Insufficient balance to proceed with Transaction. Please ensure that you have sufficient balance to convert into new currency unit. Operation Terminated.");
            throw new InvalidTransactionException("Amount to convert is greater than balance in wallet.");
	    }
	}
	/**
	 * Update the contents of user's wallet in a new file in json format
	 * @param users
	 * @throws StreamWriteException
	 * @throws DatabindException
	 * @throws IOException
	 */
	public void updateUsersFile(User[] users) throws StreamWriteException, DatabindException, IOException {
			File output = new File(".\\src\\main\\resources\\UsersUpdated.json");
			ObjectMapper mapper = new ObjectMapper();
			mapper.writeValue(output, users);
	}
	/**
	 * Deserialize Users.json file to extract the users in system
	 * @return User[] users 
	 */
	public static User[] getUsers() {
		ObjectMapper mapper = new ObjectMapper();
		User[] users = null;
		try {
			users = mapper.readValue(new File(".\\src\\main\\resources\\Users.json"), User[].class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return users;	
	}
	/**
	 * Deserialize fx_rates.json file to extract the currency given
	 * @return Currency[] currency
	 */
	public static Currency[] getCurrency() {
		ObjectMapper mapper = new ObjectMapper();
		Currency[] currency = null;
		try {
			currency = mapper.readValue(new File(".\\src\\main\\resources\\fx_rates.json"), Currency[].class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return currency;
	}
}
