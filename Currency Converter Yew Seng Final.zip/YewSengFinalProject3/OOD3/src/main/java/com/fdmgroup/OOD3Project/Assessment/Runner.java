package com.fdmgroup.OOD3Project.Assessment;


import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
/**
 * Main Class to execute all commands
 * @author Tan Yew Seng
 * @version 1.0
 */
public class Runner {

	/**
	 * Main method to execute all commands here
	 * @param args
	 * @throws InvalidTransactionException
	 * @throws InvalidUserException
	 * @throws InvalidAmountException
	 * @throws IOException
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException {
		Logger log = (Logger) LogManager.getLogger(TransactionProcessor.class);
		TransactionProcessor processor = new TransactionProcessor();
		try {
			processor.executeTransaction();
		} catch (InvalidTransactionException|InvalidUserException|InvalidAmountException e) {
			log.fatal(e.getMessage());
			System.out.println("Exceptions spotted, check output.log file for more information. Thanks!");
		}
	}

}
