package com.fdmgroup.OOD3Project.Assessment;

import java.io.File;
import java.io.IOException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * Class to convert old currency value to new currency value given the exchange rates provided in the fx_rates.json
 * @author Tan Yew Seng
 * @version 1.0
 */
public class Converter {
	/**
	 * Converts money from {@code originalCurrency} to {@code newCurrency}.  
	 * Will throw InvalidTransactionException if any of the following occurs
	 * <li> {@code originalCurrency}  equals to {@code newCurrency}
	 * <li> {@code amount} <= 0
	 * @param originalCurrency
	 * @param newCurrency
	 * @param amount
	 * @return valueToAdd the equivalent value of converted currency in new currency
	 * @throws InvalidTransactionException
	 */
	public double convert(String originalCurrency, String newCurrency, double amount) throws InvalidTransactionException{
		ObjectMapper mapper = new ObjectMapper();	
		double valueToAdd = 0.0;
		Logger log = (Logger) LogManager.getLogger(Converter.class);
		try {
			if (amount <= 0) {
				log.error("Invalid operation - Cannot convert negative/zero value to "+ newCurrency+ ". Operation Terminated. ");
				throw new InvalidTransactionException("Cannot convert negative/zero value currency");
			}
			else if (originalCurrency.equals("usd")) {
				// Get the concrete implementation of JsonNode that maps to the individual currency
				JsonNode node = mapper.readTree(new File(".\\src\\main\\resources\\fx_rates.json"));
				//Read the respective value of the currency rate as JsonNode format
				JsonNode rateNode = node.findValue(newCurrency).get("rate");
				//Convert the rate to a double
				double rate = rateNode.asDouble();
				valueToAdd = amount * rate;
			}
			else if (newCurrency.equals("usd")) {
				// Get the concrete implementation of JsonNode that maps to the individual currency
				JsonNode node = mapper.readTree(new File(".\\src\\main\\resources\\fx_rates.json"));
				//Read the respective value of the currency inverseRate as JsonNode format
				JsonNode inverseRateNode = node.findValue(originalCurrency).get("inverseRate");
				//Convert inverseRate to double
				double inverseRate = inverseRateNode.asDouble();
				valueToAdd = amount * inverseRate;		
			} else {
				// Get the concrete implementation of JsonNode that maps to the individual currency
				JsonNode node = mapper.readTree(new File(".\\src\\main\\resources\\fx_rates.json"));
				//Read the respective value of the currency rate as JsonNode format
				JsonNode rateNode = node.findValue(newCurrency).get("rate");
				//Read the respective value of the currency inverseRate as JsonNode format
				JsonNode inverseRateNode = node.findValue(originalCurrency).get("inverseRate");
				//Convert the rate to a double
				double rate = rateNode.asDouble();
				//Convert inverseRate to double
				double inverseRate = inverseRateNode.asDouble();
				valueToAdd = amount * inverseRate * rate;		
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return valueToAdd;	
	}
}
